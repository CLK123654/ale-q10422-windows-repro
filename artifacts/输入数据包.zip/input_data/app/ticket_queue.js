const state = {
  tickets: [],
  selected: new Set(),
  offset: 0,
  lastSnapshot: null,
  rules: null
};

const list = document.querySelector('[data-testid="ticket-list"]');
const counter = document.querySelector('[data-testid="selected-counter"]');
const rangeLabel = document.querySelector('[data-testid="range-label"]');
const snackbar = document.querySelector('[data-testid="undo-snackbar"]');

async function boot() {
  const [ticketResponse, ruleResponse] = await Promise.all([
    fetch('/api/tickets'),
    fetch('/api/bulk-rules')
  ]);
  state.tickets = await ticketResponse.json();
  state.rules = await ruleResponse.json();
  render();
}

function selectable(ticket) {
  return !state.rules.non_selectable_statuses.includes(ticket.status);
}

function render() {
  const size = state.rules.visible_window_size;
  const end = Math.min(state.offset + size, state.tickets.length);
  rangeLabel.textContent = 'Showing ' + (state.offset + 1) + '-' + end + ' of ' + state.tickets.length;
  list.innerHTML = '';
  for (let index = state.offset; index < end; index += 1) {
    const ticket = state.tickets[index];
    const row = document.createElement('div');
    row.className = 'row';
    row.dataset.testid = 'ticket-row-' + ticket.ticket_id;
    row.setAttribute('role', 'option');
    row.setAttribute('aria-rowindex', String(ticket.row_position));
    row.setAttribute('aria-disabled', selectable(ticket) ? 'false' : 'true');
    const checked = state.selected.has(ticket.ticket_id);
    row.innerHTML = '<input type="checkbox" data-testid="ticket-check-' + ticket.ticket_id + '" aria-label="Select ' + ticket.ticket_id + '" aria-checked="' + checked + '"' + (checked ? ' checked' : '') + (selectable(ticket) ? '' : ' disabled') + '>' +
      '<span>' + ticket.ticket_id + '</span><span>' + ticket.queue + '</span><span>' + ticket.priority + '</span><span data-testid="ticket-status-' + ticket.ticket_id + '">' + ticket.status + '</span><span data-testid="ticket-assignee-' + ticket.ticket_id + '">' + ticket.assignee + '</span><span>' + ticket.subject + '</span>';
    row.querySelector('input').addEventListener('change', (event) => {
      if (event.target.checked) state.selected.add(ticket.ticket_id);
      else state.selected.delete(ticket.ticket_id);
      updateCounter();
      render();
    });
    list.appendChild(row);
  }
  updateCounter();
}

function updateCounter() {
  counter.textContent = state.selected.size + ' selected';
}

async function applyBulk(action) {
  const selectedIds = [...state.selected].filter((id) => selectable(state.tickets.find((ticket) => ticket.ticket_id === id)));
  state.lastSnapshot = state.tickets.map((ticket) => ({ ...ticket }));
  const response = await fetch('/api/tickets/bulk-action', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ action, ticket_ids: selectedIds })
  });
  const payload = await response.json();
  for (const update of payload.updated) {
    const ticket = state.tickets.find((item) => item.ticket_id === update.ticket_id);
    Object.assign(ticket, update);
  }
  state.selected.clear();
  snackbar.innerHTML = '<span>' + payload.message + '</span> <button data-testid="undo-assignment">Undo assignment</button>';
  snackbar.querySelector('button').addEventListener('click', () => {
    state.tickets = state.lastSnapshot.map((ticket) => ({ ...ticket }));
    snackbar.textContent = 'Bulk action undone';
    render();
  });
  render();
}

document.querySelector('[data-testid="scroll-start"]').addEventListener('click', () => { state.offset = 0; render(); });
document.querySelector('[data-testid="scroll-next"]').addEventListener('click', () => {
  state.offset = Math.min(state.offset + state.rules.visible_window_size, state.tickets.length - state.rules.visible_window_size);
  render();
});
document.querySelectorAll('[data-action]').forEach((button) => {
  button.addEventListener('click', () => applyBulk(button.dataset.action));
});
boot();
