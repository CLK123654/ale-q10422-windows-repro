import http from "node:http";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const port = Number(process.env.PORT || 4179);

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, "http://127.0.0.1:" + port);
  if (url.pathname === "/api/tickets") {
    res.setHeader("content-type", "application/json");
    res.end(await fs.readFile(path.join(root, "fixtures/tickets.json"), "utf8"));
    return;
  }
  if (url.pathname === "/api/bulk-rules") {
    res.setHeader("content-type", "application/json");
    res.end(await fs.readFile(path.join(root, "fixtures/bulk_rules.json"), "utf8"));
    return;
  }
  if (url.pathname === "/api/tickets/bulk-action" && req.method === "POST") {
    let body = "";
    req.on("data", (chunk) => { body += chunk; });
    req.on("end", async () => {
      const payload = JSON.parse(body || "{}");
      const rules = JSON.parse(await fs.readFile(path.join(root, "fixtures/bulk_rules.json"), "utf8"));
      const action = rules.actions[payload.action];
      const updated = (payload.ticket_ids || []).map((ticket_id) => ({
        ticket_id,
        status: action.final_status,
        assignee: action.assignee
      }));
      res.setHeader("content-type", "application/json");
      res.end(JSON.stringify({ message: action.snackbar, updated }));
    });
    return;
  }
  const file = url.pathname === "/" ? "app/ticket_queue.html" : url.pathname.slice(1);
  try {
    const content = await fs.readFile(path.join(root, file));
    res.end(content);
  } catch {
    res.statusCode = 404;
    res.end("not found");
  }
});
server.listen(port, () => console.log("ticket queue server http://127.0.0.1:" + port));
