# 工单队列虚拟列表材料

客服工具团队要在上线前检查虚拟列表工单页。app是本地页面，fixtures保存脱敏工单、批量规则和业务场景。starter只含最小配置与冒烟检查，需要补成完整的Playwright浏览器回归。

完成output/playwright.config.ts和output/tests/ticket_queue_virtual_list.spec.ts后，在input_data根目录运行npm run process。入口会选择空闲回环端口并启动Chromium，测试从真实页面交互与route请求整理选择矩阵、撤销时序和ARIA合同报告。

环境需预先安装Node.js20或更高版本、Playwright1.62.x和对应Chromium。业务运行只访问本机，不连接真实客服系统，也不依赖WSL、Bash或Linux容器。
