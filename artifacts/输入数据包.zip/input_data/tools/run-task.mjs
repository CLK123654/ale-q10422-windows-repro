import fs from 'node:fs/promises';
import net from 'node:net';
import path from 'node:path';
import process from 'node:process';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const output = path.join(root, 'output');
const configPath = path.join(output, 'playwright.config.ts');
const testPath = path.join(output, 'tests', 'ticket_queue_virtual_list.spec.ts');
const reportsPath = path.join(output, 'reports');
const requiredInput = [
  'README.md',
  'app/ticket_queue.html',
  'app/ticket_queue.js',
  'fixtures/bulk_rules.json',
  'fixtures/selection_cases.csv',
  'fixtures/tickets.json',
  'package.json',
  'scripts/static_server.mjs',
  'starter/playwright.config.ts',
  'starter/tests/ticket_queue_virtual_list.spec.ts'
];
const requiredOutput = [
  'output/playwright.config.ts',
  'output/reports/aria_contract_report.csv',
  'output/reports/selection_matrix.csv',
  'output/reports/undo_timing_report.csv',
  'output/tests/ticket_queue_virtual_list.spec.ts'
];

async function exists(target) {
  try { await fs.access(target); return true; } catch { return false; }
}

async function cleanReports() {
  await fs.rm(reportsPath, { recursive: true, force: true });
}

async function cleanTransient() {
  await fs.rm(path.join(root, 'test-results'), { recursive: true, force: true });
  await fs.rm(path.join(output, 'test-results'), { recursive: true, force: true });
  await fs.rm(path.join(root, 'playwright-report'), { recursive: true, force: true });
  await fs.rm(path.join(root, '.playwright-artifacts'), { recursive: true, force: true });
}

async function listFiles(directory, prefix = '') {
  const entries = await fs.readdir(directory, { withFileTypes: true });
  const result = [];
  for (const entry of entries.sort((left, right) => left.name.localeCompare(right.name))) {
    const relative = path.posix.join(prefix, entry.name);
    if (entry.isDirectory()) result.push(...await listFiles(path.join(directory, entry.name), relative));
    else result.push(relative);
  }
  return result;
}

async function freePort() {
  const server = net.createServer();
  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });
  const address = server.address();
  const port = typeof address === 'object' && address ? address.port : 0;
  await new Promise(resolve => server.close(resolve));
  if (!port) throw new Error('无法分配本地回环端口');
  return port;
}

function playwrightCli() {
  if (process.env.PLAYWRIGHT_CLI) return path.resolve(process.env.PLAYWRIGHT_CLI);
  return path.join(root, 'node_modules', 'playwright', 'cli.js');
}

try {
  await cleanReports();
  await cleanTransient();
  for (const relative of requiredInput) {
    if (!await exists(path.join(root, relative))) throw Object.assign(new Error(`缺少输入：${relative}`), { exitCode: 2 });
  }
  if (!await exists(configPath) || !await exists(testPath)) {
    throw Object.assign(new Error('请完成output/playwright.config.ts和output/tests/ticket_queue_virtual_list.spec.ts'), { exitCode: 2 });
  }
  const cli = playwrightCli();
  if (!await exists(cli)) throw Object.assign(new Error('未找到Playwright1.62.x，请在作业环境预先安装'), { exitCode: 2 });
  const versionRun = spawnSync(process.execPath, [cli, '--version'], { encoding: 'utf8', windowsHide: true, timeout: 10000 });
  if (versionRun.status !== 0 || !/Version 1\.62\./.test(versionRun.stdout)) throw new Error(`需要Playwright1.62.x：${versionRun.stdout || versionRun.stderr}`);
  const port = await freePort();
  const run = spawnSync(process.execPath, [cli, 'test', '--config', configPath], {
    cwd: root,
    env: { ...process.env, PORT: String(port), TICKET_QUEUE_PORT: String(port) },
    encoding: 'utf8',
    windowsHide: true,
    timeout: 120000
  });
  if (run.stdout) process.stdout.write(run.stdout);
  if (run.stderr) process.stderr.write(run.stderr);
  if (run.error || run.status !== 0) throw new Error(`Playwright返回${run.status ?? 'spawn_error'}`);
  await cleanTransient();
  const files = (await listFiles(output)).map(name => `output/${name}`);
  if (JSON.stringify(files) !== JSON.stringify(requiredOutput)) throw new Error(`交付边界不符：${files.join(',')}`);
  console.log('工单队列浏览器回归完成');
} catch (error) {
  await cleanReports();
  await cleanTransient();
  console.error(error instanceof Error ? error.message : String(error));
  process.exit(Number.isInteger(error?.exitCode) ? error.exitCode : 1);
}
