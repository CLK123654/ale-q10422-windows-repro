import { test, expect } from 'playwright/test';

test('TODO: cover virtualized queue selection, bulk action and undo', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByRole('heading', { name: '客服工单队列' })).toBeVisible();
});
