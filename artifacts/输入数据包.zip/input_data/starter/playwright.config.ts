import { defineConfig } from 'playwright/test';

export default defineConfig({
  testDir: './tests',
  timeout: 30000,
  use: {
    baseURL: 'http://127.0.0.1:4179',
    trace: 'retain-on-failure'
  },
  webServer: {
    command: 'node scripts/static_server.mjs',
    url: 'http://127.0.0.1:4179',
    reuseExistingServer: !process.env.CI
  }
});
