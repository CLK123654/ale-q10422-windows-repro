import { defineConfig } from 'playwright/test';

const port = Number(process.env.TICKET_QUEUE_PORT || '4179');

export default defineConfig({
  testDir: './tests',
  workers: 1,
  fullyParallel: false,
  retries: 0,
  timeout: 45000,
  reporter: [['line']],
  outputDir: '../test-results',
  use: {
    baseURL: `http://127.0.0.1:${port}`,
    timezoneId: 'Asia/Shanghai',
    trace: 'off',
    screenshot: 'off',
    video: 'off'
  },
  projects: [{ name: 'chromium', use: { browserName: 'chromium' } }],
  webServer: {
    command: 'node scripts/static_server.mjs',
    cwd: process.cwd(),
    url: `http://127.0.0.1:${port}`,
    reuseExistingServer: false,
    timeout: 15000
  }
});
