import { test, expect, type Locator, type Page } from 'playwright/test';
import fsSync from 'node:fs';
import fs from 'node:fs/promises';
import path from 'node:path';

type CsvRow = Record<string, string>;
type Ticket = {
  ticket_id: string;
  row_position: number;
  queue: string;
  priority: string;
  status: string;
  assignee: string;
  subject: string;
  selectable: boolean;
};

const root = process.cwd();
const reportsDir = path.join(root, 'output', 'reports');
const tickets: Ticket[] = JSON.parse(fsSync.readFileSync(path.join(root, 'fixtures', 'tickets.json'), 'utf8'));
const rules = JSON.parse(fsSync.readFileSync(path.join(root, 'fixtures', 'bulk_rules.json'), 'utf8'));
const cases = parseCsv(fsSync.readFileSync(path.join(root, 'fixtures', 'selection_cases.csv'), 'utf8'));

function parseCsv(text: string): CsvRow[] {
  const records: string[][] = [];
  let record: string[] = [];
  let field = '';
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    if (quoted) {
      if (char === '"' && text[index + 1] === '"') { field += '"'; index += 1; }
      else if (char === '"') quoted = false;
      else field += char;
    } else if (char === '"') quoted = true;
    else if (char === ',') { record.push(field); field = ''; }
    else if (char === '\n') { record.push(field.replace(/\r$/, '')); records.push(record); record = []; field = ''; }
    else field += char;
  }
  if (field || record.length) { record.push(field.replace(/\r$/, '')); records.push(record); }
  const [headers, ...rows] = records.filter(row => row.some(value => value !== ''));
  return rows.map(row => Object.fromEntries(headers.map((header, index) => [header, row[index] ?? ''])));
}

function csvEscape(value: unknown) {
  const text = String(value ?? '');
  return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

function toCsv(headers: string[], rows: Record<string, unknown>[]) {
  return `${[headers.join(','), ...rows.map(row => headers.map(header => csvEscape(row[header])).join(','))].join('\n')}\n`;
}

function pipeValues(value: string) {
  return value ? value.split('|').filter(Boolean) : [];
}

function isSelectable(ticket: Ticket) {
  return !rules.non_selectable_statuses.includes(ticket.status);
}

async function scrollToTicket(page: Page, ticketId: string): Promise<{ checkbox: Locator; row: Locator; windowLabel: string; rendered: number }> {
  await page.getByTestId('scroll-start').click();
  const maximumWindows = Math.ceil(tickets.length / rules.visible_window_size) + 1;
  for (let attempt = 0; attempt < maximumWindows; attempt += 1) {
    const checkbox = page.getByTestId(`ticket-check-${ticketId}`);
    const rendered = await page.locator('[data-testid=ticket-list] [role=option]').count();
    expect(rendered).toBeLessThanOrEqual(rules.rendered_row_ceiling);
    if (await checkbox.count()) {
      return {
        checkbox,
        row: page.getByTestId(`ticket-row-${ticketId}`),
        windowLabel: await page.getByTestId('range-label').innerText(),
        rendered
      };
    }
    await page.getByTestId('scroll-next').click();
  }
  throw new Error(`ticket not rendered by virtual list: ${ticketId}`);
}

test.beforeAll(async () => {
  await fs.rm(reportsDir, { recursive: true, force: true });
  await fs.mkdir(reportsDir, { recursive: true });
});

test('虚拟窗口选择、禁选规则、请求归并与撤销恢复', async ({ page }) => {
  const capturedRequests: Array<{ case_id: string; action: string; ticket_ids: string[] }> = [];
  const externalRequests: string[] = [];
  const selectionRows: Record<string, unknown>[] = [];
  const timingRows: Record<string, unknown>[] = [];
  let activeCase = '';
  let maxRendered = 0;
  let countersMatched = true;
  let snackbarRolesMatched = true;

  await page.addInitScript(({ fixedNow }) => {
    let controlledNow = Date.parse(fixedNow);
    Date.now = () => controlledNow;
    (window as any).__advanceAuditClock = (milliseconds: number) => { controlledNow += milliseconds; };
  }, { fixedNow: rules.audit_clock.fixed_now_utc });
  page.on('request', request => {
    const url = new URL(request.url());
    if (!['127.0.0.1', 'localhost'].includes(url.hostname)) externalRequests.push(request.url());
  });
  await page.route(`**${rules.endpoints.list}`, route =>
    route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(tickets) })
  );
  await page.route(`**${rules.endpoints.rules}`, route =>
    route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(rules) })
  );
  await page.route(`**${rules.endpoints.bulk_action}`, async route => {
    const payload = route.request().postDataJSON() as { action: string; ticket_ids: string[] };
    capturedRequests.push({ case_id: activeCase, action: payload.action, ticket_ids: [...payload.ticket_ids] });
    const action = rules.actions[payload.action];
    expect(action).toBeTruthy();
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        message: action.snackbar,
        updated: payload.ticket_ids.map(ticket_id => ({ ticket_id, status: action.final_status, assignee: action.assignee }))
      })
    });
  });

  await page.goto('/');
  await expect(page.getByRole('heading', { name: '客服工单队列' })).toBeVisible();
  await expect(page.getByTestId('ticket-list')).toHaveAttribute('role', 'listbox');
  await expect(page.getByTestId('bulk-toolbar')).toHaveAttribute('aria-live', 'polite');
  const initialEnd = Math.min(rules.visible_window_size, tickets.length);
  await expect(page.getByTestId('range-label')).toHaveText(`Showing 1-${initialEnd} of ${tickets.length}`);

  for (const scenario of cases) {
    activeCase = scenario.case_id;
    const targetIds = pipeValues(scenario.ticket_ids);
    const blockedIds = new Set(pipeValues(scenario.expected_blocked_ids));
    const expectedSelectableCount = Number(scenario.expected_selectable_count);
    const caseRows: Record<string, unknown>[] = [];
    for (const ticketId of targetIds) {
      const ticket = tickets.find(candidate => candidate.ticket_id === ticketId);
      expect(ticket).toBeTruthy();
      const located = await scrollToTicket(page, ticketId);
      maxRendered = Math.max(maxRendered, located.rendered);
      await expect(located.row).toHaveAttribute('aria-rowindex', String(ticket!.row_position));
      const selectable = isSelectable(ticket!);
      expect(selectable).toBe(!blockedIds.has(ticketId));
      expect(ticket!.selectable).toBe(selectable);
      if (selectable) {
        await expect(located.checkbox).toBeEnabled();
        await located.checkbox.check();
        await expect(page.getByTestId(`ticket-check-${ticketId}`)).toHaveAttribute('aria-checked', 'true');
      } else {
        await expect(located.checkbox).toBeDisabled();
        await expect(located.row).toHaveAttribute('aria-disabled', 'true');
      }
      caseRows.push({
        case_id: scenario.case_id,
        ticket_id: ticketId,
        row_position: ticket!.row_position,
        scroll_window: located.windowLabel.replace(/^Showing /, '').replace(/ of \d+$/, ''),
        selectable: selectable ? 'yes' : 'no',
        selected_before_action: selectable ? 'yes' : 'no',
        action: scenario.action,
        request_included: selectable ? 'yes' : 'no',
        final_status: '',
        final_assignee: '',
        reason: selectable ? 'action_applied' : `status_${ticket!.status}`
      });
    }
    expect(caseRows.filter(row => row.selected_before_action === 'yes')).toHaveLength(expectedSelectableCount);
    await expect(page.getByTestId('selected-counter')).toHaveText(`${expectedSelectableCount} selected`);
    countersMatched &&= await page.getByTestId('selected-counter').innerText() === `${expectedSelectableCount} selected`;
    for (const row of caseRows.filter(candidate => candidate.selected_before_action === 'yes')) {
      const located = await scrollToTicket(page, String(row.ticket_id));
      await expect(located.checkbox).toBeChecked();
      await expect(located.checkbox).toHaveAttribute('aria-checked', 'true');
    }

    const actionRule = rules.actions[scenario.action];
    expect(actionRule?.button_testid).toBeTruthy();
    const requestCountBefore = capturedRequests.length;
    await page.getByTestId(actionRule.button_testid).click();
    await expect.poll(() => capturedRequests.length).toBe(requestCountBefore + 1);
    const request = capturedRequests.at(-1)!;
    const expectedRequestIds = caseRows.filter(row => row.request_included === 'yes').map(row => String(row.ticket_id));
    expect(request).toEqual({ case_id: scenario.case_id, action: scenario.action, ticket_ids: expectedRequestIds });

    const snackbar = page.getByTestId('undo-snackbar');
    await expect(snackbar).toHaveAttribute('role', 'status');
    await expect(snackbar).toContainText(actionRule.snackbar);
    snackbarRolesMatched &&= await snackbar.getAttribute('role') === 'status';
    const undoButton = page.getByRole('button', { name: 'Undo assignment' });
    await expect(undoButton).toBeVisible();
    const visibleAt = await page.evaluate(() => Date.now());
    let clickedAfter: number | '' = '';
    let restoredCount = 0;
    if (scenario.expected_result === 'undone') {
      await page.evaluate(milliseconds => (window as any).__advanceAuditClock(milliseconds), rules.audit_clock.undo_click_delay_ms);
      clickedAfter = (await page.evaluate(() => Date.now())) - visibleAt;
      await undoButton.click();
      await expect(snackbar).toHaveText('Bulk action undone');
      restoredCount = expectedRequestIds.length;
    }
    await expect(page.getByTestId('selected-counter')).toHaveText('0 selected');

    for (const row of caseRows) {
      const ticket = tickets.find(candidate => candidate.ticket_id === row.ticket_id)!;
      const applied = row.request_included === 'yes' && scenario.expected_result !== 'undone';
      row.final_status = applied ? actionRule.final_status : ticket.status;
      row.final_assignee = applied ? actionRule.assignee : ticket.assignee;
      if (scenario.expected_result === 'undone' && row.request_included === 'yes') row.reason = 'undo_restored';
      const located = await scrollToTicket(page, String(row.ticket_id));
      await expect(located.row).toContainText(String(row.final_status));
      await expect(located.row).toContainText(String(row.final_assignee));
    }
    selectionRows.push(...caseRows);
    timingRows.push({
      case_id: scenario.case_id,
      snackbar_role: 'status',
      snackbar_text: actionRule.snackbar,
      selected_count: expectedSelectableCount,
      undo_button_name: 'Undo assignment',
      undo_clicked: scenario.expected_result === 'undone' ? 'yes' : 'no',
      clicked_after_ms: clickedAfter,
      configured_timeout_ms: rules.undo_timeout_ms,
      restored_ticket_count: restoredCount,
      final_toolbar_count: 0
    });
  }

  const targetIds = cases.flatMap(scenario => pipeValues(scenario.ticket_ids));
  const blockedTargetIds = selectionRows.filter(row => row.selectable === 'no').map(row => String(row.ticket_id));
  const furthestTicket = targetIds.map(id => tickets.find(ticket => ticket.ticket_id === id)!).sort((left, right) => right.row_position - left.row_position)[0];
  const furthest = await scrollToTicket(page, furthestTicket.ticket_id);
  const largestCase = [...cases].sort((left, right) => Number(right.expected_selectable_count) - Number(left.expected_selectable_count))[0];
  const ariaRows = [
    { assertion_key: 'ticket-list-role', selector_or_name: '[data-testid=ticket-list]', expected_property: 'role', expected_value: await page.getByTestId('ticket-list').getAttribute('role'), evidence: 'Playwright getAttribute' },
    { assertion_key: 'row-index', selector_or_name: 'ticket rows', expected_property: 'aria-rowindex', expected_value: `1..${tickets.length}`, evidence: '每个目标行的真实属性断言' },
    { assertion_key: 'checkbox-state', selector_or_name: 'ticket checkboxes', expected_property: 'aria-checked', expected_value: 'true for selected rows', evidence: '跨窗口重新定位后toBeChecked' },
    { assertion_key: 'disabled-targets', selector_or_name: blockedTargetIds.join('/'), expected_property: 'aria-disabled', expected_value: 'true', evidence: '禁选行的真实属性断言' },
    { assertion_key: 'selected-counter', selector_or_name: '[data-testid=selected-counter]', expected_property: 'text', expected_value: `${largestCase.expected_selectable_count} selected after ${largestCase.case_id}`, evidence: '动作前工具栏断言' },
    { assertion_key: 'range-label', selector_or_name: '[data-testid=range-label]', expected_property: 'text', expected_value: furthest.windowLabel, evidence: `滚动到row_position=${furthestTicket.row_position}` },
    { assertion_key: 'snackbar-role', selector_or_name: '[data-testid=undo-snackbar]', expected_property: 'role', expected_value: 'status', evidence: '每个场景的真实属性断言' },
    { assertion_key: 'undo-name', selector_or_name: 'button', expected_property: 'accessible name', expected_value: 'Undo assignment', evidence: 'getByRole(button,name)' },
    { assertion_key: 'bulk-live', selector_or_name: '[data-testid=bulk-toolbar]', expected_property: 'aria-live', expected_value: await page.getByTestId('bulk-toolbar').getAttribute('aria-live'), evidence: 'Playwright getAttribute' }
  ];

  expect(new Set(cases.map(scenario => scenario.case_id)).size).toBe(cases.length);
  expect(maxRendered).toBeLessThanOrEqual(rules.rendered_row_ceiling);
  expect(capturedRequests.every(request => request.ticket_ids.every(id => isSelectable(tickets.find(ticket => ticket.ticket_id === id)!)))).toBeTruthy();
  expect(blockedTargetIds.every(id => !capturedRequests.some(request => request.ticket_ids.includes(id)))).toBeTruthy();
  expect(snackbarRolesMatched && countersMatched).toBeTruthy();
  expect(externalRequests).toEqual([]);

  await fs.writeFile(path.join(reportsDir, 'selection_matrix.csv'), toCsv(
    ['case_id', 'ticket_id', 'row_position', 'scroll_window', 'selectable', 'selected_before_action', 'action', 'request_included', 'final_status', 'final_assignee', 'reason'], selectionRows
  ));
  await fs.writeFile(path.join(reportsDir, 'undo_timing_report.csv'), toCsv(
    ['case_id', 'snackbar_role', 'snackbar_text', 'selected_count', 'undo_button_name', 'undo_clicked', 'clicked_after_ms', 'configured_timeout_ms', 'restored_ticket_count', 'final_toolbar_count'], timingRows
  ));
  await fs.writeFile(path.join(reportsDir, 'aria_contract_report.csv'), toCsv(
    ['assertion_key', 'selector_or_name', 'expected_property', 'expected_value', 'evidence'], ariaRows
  ));
});
